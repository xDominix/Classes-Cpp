#ifndef MATRIX_ELEMENT
#define MATRIX_ELEMENT

using MatrixElement = int;

#endif // MATRIX_ELEMENT
